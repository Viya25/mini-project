# backend/utils/predictor.py
import cv2
import numpy as np
import os

# Use OpenCV's built-in face cascade (should be available in cv2.data.haarcascades)
FACE_CASCADE_PATH = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
face_cascade = cv2.CascadeClassifier(FACE_CASCADE_PATH)

def measure_sharpness(gray):
    # variance of Laplacian -> low = blurry
    return cv2.Laplacian(gray, cv2.CV_64F).var()

def color_variance(bgr):
    # measure how colorful the face region is (print/photo attacks often have lower chroma variation)
    # convert to HSV and take variance of saturation and value
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    s_var = np.var(hsv[:,:,1])
    v_var = np.var(hsv[:,:,2])
    return float(s_var), float(v_var)

def face_coverage(face_bbox, image_shape):
    # how much of the image area the face occupies (small faces in photos/screenshots may indicate attack)
    x,y,w,h = face_bbox
    img_h, img_w = image_shape[:2]
    face_area = w*h
    return face_area / (img_w*img_h + 1e-9)

def analyze_face_region(bgr, bbox):
    x,y,w,h = bbox
    face = bgr[y:y+h, x:x+w].copy()
    gray = cv2.cvtColor(face, cv2.COLOR_BGR2GRAY)
    sharpness = measure_sharpness(gray)
    s_var, v_var = color_variance(face)
    coverage = face_coverage((x,y,w,h), bgr.shape)
    return {
        'sharpness': float(sharpness),
        's_var': float(s_var),
        'v_var': float(v_var),
        'coverage': float(coverage)
    }

def decide_label_from_metrics(metrics):
    # Heuristic thresholds (tweakable)
    # If sharpness high and color variance high and coverage sensible => real
    # Else => fake
    sharp = metrics['sharpness']
    s_var = metrics['s_var']
    v_var = metrics['v_var']
    cov = metrics['coverage']

    score = 0.0
    # sharpness contribution (normalized)
    score += min(sharp / 300.0, 1.0) * 0.5  # weight 0.5
    # color variance
    score += min((s_var + v_var) / 2000.0, 1.0) * 0.3  # weight 0.3
    # coverage: encourage faces that are not tiny (<0.01) and not extremely large
    if 0.03 <= cov <= 0.6:
        score += 0.2
    elif cov > 0.6:
        score += 0.1
    # final label & confidence
    label = 'real' if score >= 0.45 else 'fake'
    confidence = float(round(score, 2))
    # clamp
    if confidence < 0.01: confidence = 0.01
    if confidence > 0.99: confidence = 0.99
    return label, confidence

def detect_faces_in_image(img_bgr):
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(40,40))
    return faces

def analyze_image_file(filepath):
    """
    Analyze a single image file and return label/confidence + metrics.
    """
    img = cv2.imread(filepath)
    if img is None:
        return {'label': 'error', 'confidence': 0.0, 'reason': 'cannot_read_image'}

    faces = detect_faces_in_image(img)
    if len(faces) == 0:
        # no face detected -> likely not usable / possibly fake
        return {'label': 'fake', 'confidence': 0.2, 'reason': 'no_face_detected'}

    # analyze largest face
    faces_sorted = sorted(faces, key=lambda r: r[2]*r[3], reverse=True)
    x,y,w,h = faces_sorted[0]
    metrics = analyze_face_region(img, (x,y,w,h))
    label, confidence = decide_label_from_metrics(metrics)
    return {
        'label': label,
        'confidence': confidence,
        'metrics': metrics,
        'num_faces': int(len(faces))
    }

def analyze_video_file(filepath, sample_every_n_frames=10, max_frames=60):
    """
    Sample frames from the video and run image heuristic on each sampled frame.
    Aggregate results and return majority label + average confidence.
    """
    cap = cv2.VideoCapture(filepath)
    if not cap.isOpened():
        return {'label': 'error', 'confidence': 0.0, 'reason': 'cannot_open_video'}

    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    fps = cap.get(cv2.CAP_PROP_FPS) or 0
    results = []
    frames_processed = 0
    frame_idx = 0
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        if frame_idx % sample_every_n_frames == 0:
            res = analyze_image_frame(frame)
            if res:
                results.append(res)
                frames_processed += 1
        frame_idx += 1
        if frames_processed >= max_frames:
            break
    cap.release()

    if len(results) == 0:
        return {'label': 'fake', 'confidence': 0.2, 'reason': 'no_valid_frames'}

    # aggregate: majority label, average confidence
    real_count = sum(1 for r in results if r['label'] == 'real')
    fake_count = sum(1 for r in results if r['label'] == 'fake')
    avg_conf = float(round(sum(r['confidence'] for r in results) / len(results), 2))
    label = 'real' if real_count >= fake_count else 'fake'
    return {
        'label': label,
        'confidence': avg_conf,
        'frames_analyzed': len(results),
        'frame_results': results[:10]  # include first few frame-level results for debugging
    }

def analyze_image_frame(frame_bgr):
    try:
        faces = detect_faces_in_image(frame_bgr)
        if len(faces) == 0:
            return {'label': 'fake', 'confidence': 0.2, 'reason': 'no_face'}
        faces_sorted = sorted(faces, key=lambda r: r[2]*r[3], reverse=True)
        x,y,w,h = faces_sorted[0]
        metrics = analyze_face_region(frame_bgr, (x,y,w,h))
        label, confidence = decide_label_from_metrics(metrics)
        return {
            'label': label,
            'confidence': confidence,
            'metrics': metrics
        }
    except Exception as e:
        return None
