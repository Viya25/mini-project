const video = document.getElementById('video');
const startBtn = document.getElementById('startBtn');
const snapBtn = document.getElementById('snapBtn');
const previewImg = document.getElementById('previewImg');
const uploadBtn = document.getElementById('uploadBtn');
const uploadInput = document.getElementById('uploadInput');
const resultBox = document.getElementById('result');
const recentList = document.getElementById('recentList');

// Start camera
startBtn.onclick = async () => {
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 } });
        video.srcObject = stream;
        startBtn.disabled = true;
    } catch (err) {
        alert('Camera access denied or unavailable.');
        console.error(err);
    }
};

// Capture frame
snapBtn.onclick = async () => {
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0);
    const blob = await new Promise(resolve => canvas.toBlob(resolve, 'image/jpeg'));
    previewImg.src = URL.createObjectURL(blob);
    resultBox.innerHTML = "Analyzing...";
    await sendToBackend(blob);
};

// Upload image
uploadBtn.onclick = () => uploadInput.click();
uploadInput.onchange = async (ev) => {
    const file = ev.target.files[0];
    if (!file) return;
    previewImg.src = URL.createObjectURL(file);
    resultBox.innerHTML = "Analyzing...";
    await sendToBackend(file);
};

// Send captured/uploaded image to backend
async function sendToBackend(fileBlob) {
    try {
        const formData = new FormData();
        formData.append("file", fileBlob, "image.jpg");

        const response = await fetch("http://127.0.0.1:5000/predict", {
            method: "POST",
            body: formData
        });

        const result = await response.json();

        if (result.error) {
            resultBox.innerHTML = `<span style="color:red">${result.error}</span>`;
            return;
        }

        resultBox.innerHTML = `
            <div><strong>Prediction:</strong> ${result.label.toUpperCase()}</div>
            <div><strong>Confidence:</strong> ${(result.confidence * 100).toFixed(1)}%</div>
            <div><strong>Processing time:</strong> ${result.processing_time_ms} ms</div>
        `;

        appendRecent(result, previewImg.src);

    } catch (e) {
        console.error(e);
        resultBox.innerHTML = 'Detection failed. Is backend running?';
    }
}

// Add recent detections list
function appendRecent(item, imgSrc) {
    const d = document.createElement('div');
    d.style.display = 'flex';
    d.style.alignItems = 'center';
    d.style.gap = '8px';
    d.style.marginBottom = '5px';

    const img = document.createElement('img');
    img.src = imgSrc;
    img.width = 80;
    img.height = 60;
    img.style.objectFit = 'cover';
    img.style.borderRadius = '6px';

    const info = document.createElement('div');
    info.innerHTML = `
        <div style="font-weight:700">${item.label.toUpperCase()}</div>
        <div style="font-size:12px;color:#777">${item.timestamp}</div>
        <div style="font-size:12px;color:#777">conf ${(item.confidence * 100).toFixed(1)}%</div>
    `;

    d.appendChild(img);
    d.appendChild(info);
    recentList.prepend(d);
}
